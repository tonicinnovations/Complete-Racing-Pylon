
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, login_required, login_user, logout_user, UserMixin
import json
import os
import subprocess

app = Flask(__name__)
app.secret_key = "your-secret-key"

login_manager = LoginManager()
login_manager.login_view = "login"
login_manager.init_app(app)

# Dummy user
class User(UserMixin):
    def __init__(self, id):
        self.id = id

users = {"admin": {"password": "admin"}}

@login_manager.user_loader
def load_user(user_id):
    if user_id in users:
        return User(user_id)
    return None

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        if username in users and users[username]["password"] == password:
            user = User(username)
            login_user(user)
            return redirect(url_for("pylon_control"))
        flash("Invalid username or password", "danger")
    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))

@app.route("/")
@login_required
def index():
    return redirect(url_for("pylon_control"))

@app.route("/pylon_control", methods=["GET", "POST"])
@login_required
def pylon_control():
    if request.method == "POST":
        action = request.form.get("action")
        if action == "start":
            subprocess.run(["sudo", "systemctl", "start", "pylon.service"])
        elif action == "stop":
            subprocess.run(["sudo", "systemctl", "stop", "pylon.service"])
    return render_template("pylon_control.html")

@app.route("/settings", methods=["GET", "POST"])
@login_required
def settings():
    config_path = "/home/tonicinnovations/pylon_ui/pylon_config.json"
    config = {
        "series": "XFINITY",
        "display": "last_name",
        "favorite_driver": "",
        "sync_delay": 0
    }

    if os.path.exists(config_path):
        with open(config_path) as f:
            try:
                config.update(json.load(f))
            except:
                pass

    if request.method == "POST":
        config["series"] = request.form.get("series", "XFINITY").upper()
        config["display"] = request.form.get("display", "last_name")
        config["favorite_driver"] = request.form.get("favorite_driver", "").strip()
        config["sync_delay"] = int(request.form.get("sync_delay", 0))
        with open(config_path, "w") as f:
            json.dump(config, f)
        subprocess.run(["sudo", "systemctl", "restart", "pylon.service"])
        flash("Settings saved and pylon restarted.", "success")
        return redirect(url_for("settings"))

    return render_template("settings.html",
                           current_series=config["series"],
                           current_display=config["display"],
                           favorite_driver=config["favorite_driver"],
                           sync_delay=config["sync_delay"])
